# XRPL-Hackathons
WinWin application. 

Run the main branche to execute the application. 
Wiss and Rahman branches are made by the developpers of the team. 

To run the application type "python app.py"
